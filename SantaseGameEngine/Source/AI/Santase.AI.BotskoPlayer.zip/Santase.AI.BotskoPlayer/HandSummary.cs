﻿namespace Santase.AI.BotskoPlayer
{
    internal class HandSummary
    {
        public int CountOfTrumps { get; set; }

        public int PointsOfAll { get; set; }

        public int PointsOfTrumps { get; set; }

        public int CountOfAcesNoTrumps { get; set; }
    }
}